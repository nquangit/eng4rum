CKEDITOR.plugins.setLang( 'html5audio', 'bg', {
    button: 'Вмъква HTML5 аудио',
    title: 'HTML5 аудио',
    infoLabel: 'Аудио',
    urlMissing: 'URL адресът на източника на аудио липсва.',
    audioProperties: 'Свойства на аудио',
    upload: 'Качване',
    btnUpload: 'Изпрати на сървъра',
    advanced: 'Разширено',
    autoplay: 'Автоматично изпълнение',
    allowdownload: 'Позволено изтегляне?',
    advisorytitle: 'Заглавие',
    yes: 'Да',
    no: 'Не'
} );
