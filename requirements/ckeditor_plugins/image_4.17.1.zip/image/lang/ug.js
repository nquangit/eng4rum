/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'ug', {
	alt: 'تېكىست ئالماشتۇر',
	border: 'گىرۋەك چوڭلۇقى',
	btnUpload: 'مۇلازىمېتىرغا يۈكلە',
	button2Img: 'نۆۋەتتىكى توپچىنى سۈرەتكە ئۆزگەرتەمسىز؟',
	hSpace: 'توغرىسىغا ئارىلىقى',
	img2Button: 'نۆۋەتتىكى سۈرەتنى توپچىغا ئۆزگەرتەمسىز؟',
	infoTab: 'سۈرەت',
	linkTab: 'ئۇلانما',
	lockRatio: 'نىسبەتنى قۇلۇپلا',
	menu: 'سۈرەت خاسلىقى',
	resetSize: 'ئەسلى چوڭلۇق',
	title: 'سۈرەت خاسلىقى',
	titleButton: 'سۈرەت دائىرە خاسلىقى',
	upload: 'يۈكلە',
	urlMissing: 'سۈرەتنىڭ ئەسلى ھۆججەت ئادرېسى كەم',
	vSpace: 'بويىغا ئارىلىقى',
	validateBorder: 'گىرۋەك چوڭلۇقى چوقۇم سان بولىدۇ',
	validateHSpace: 'توغرىسىغا ئارىلىق چوقۇم پۈتۈن سان بولىدۇ',
	validateVSpace: 'بويىغا ئارىلىق چوقۇم پۈتۈن سان بولىدۇ'
} );
